package ClasesEInterfaces;

import ClasesEInterfaces.Datos.LectorJson;
import ClasesEInterfaces.Datos.ListaUsuarios;
import ClasesEInterfaces.Datos.SubMenuDatos;
import ClasesEInterfaces.Juego.SubMenuJuego;

/**
 * El menu principal
 */
public class Menu implements Iniciable {
    private ListaUsuarios users = new ListaUsuarios();
    private boolean salir = false;

    /**
     * Constructor del menu
     */
    public Menu() {
        this.users = LectorJson.leerDatos(this.users, "ListaUsuarios");
    }

    /** Inicia el proceso del menu
     */
    public void iniciar() {
        this.salir = false;

        while(true) {
            while(!this.salir) {
                System.out.println("Opciones: ");
                System.out.println("1. Iniciar una partida. ");
                System.out.println("2. Manipular datos del juego (usuarios, estadísticas, partidas).");
                System.out.println("3. Salir. ");
                switch(Recibir.recibirInt("Ingrese su elección.")) {
                    case 1:
                        System.out.println("Aquí se inicia la partida.");
                        if (!this.users.getListaUsuarios().isEmpty() && this.users.getListaUsuarios().size() >= 2) {
                            SubMenuJuego subMenuJuego = new SubMenuJuego(this.users);
                            subMenuJuego.iniciar();
                            break;
                        }

                        System.out.println("Se necesitan al menos 2 jugadores registrados para jugar. Regístrelos en el menú principal");
                        break;
                    case 2:
                        SubMenuDatos subMenuDatos = new SubMenuDatos(this.users);
                        subMenuDatos.iniciar();
                        break;
                    case 3:
                        System.out.println("Adiós");
                        this.salir = true;
                        break;
                    default:
                        System.out.println("Ingrese una de las opciones sugeridas.");
                }
            }

            return;
        }
    }
}
