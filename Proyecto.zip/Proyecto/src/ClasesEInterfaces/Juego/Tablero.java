package ClasesEInterfaces.Juego;

/**
 * Tablero en el que se jugara y sus metodos pertinentes
 */
public class Tablero {
    private Ficha[][] tablero;

    /**
     * getter del tablero de la clase Tablero
     * @return la matriz tablero
     */
    public Ficha[][] getTablero() {
        return tablero;
    }

    /**
     * setter del tablero de la clase Tablero
     * @param tablero matriz tablero
     */
    public void setTablero(Ficha[][] tablero) {
        this.tablero = tablero;
    }

    /**Creacion del tablero
     */
    public Tablero() {
        this.tablero = new Ficha[15][15];
        for(int i=0; i<=14; i+=1){
            for(int j=0; j<=14; j+=1){
                tablero[i][j]= new Ficha(" ",0);
            }
        }
    }

    /**Mostrar el tablero
     */
    public void mostrarTablero(){
        for(int i=1; i<=9; i+=1){
            System.out.print(" "+i+"  ");
        }
        for(int i=10; i<=15; i+=1){
            System.out.print(" "+i+" ");
        }
        System.out.print("\n");
        int i=1;
        for(Ficha[] fila:tablero){
            if(i<10){
                System.out.print(""+i+" ");}
            else{
                System.out.print(""+i+"");
            }
            for(Ficha ficha:fila){
                System.out.print(" "+ficha.getLetra()+"| ");
            }i+=1;
            System.out.print("\n");
        }
    }

    /** El metodo colocarFicha() coloca la fixha en el tablero
     * @param ficha ficha
     * @param fila Numero de la fila
     * @param columna Numero de la columna
     */
    public void colocarFicha(Ficha ficha, int fila, int columna){
        this.tablero[fila-1][columna-1]=ficha;
    }

}
