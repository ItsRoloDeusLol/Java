import ClasesEInterfaces.Menu;

/**Clase Main que ejecuta el scrabble
 * para poder jugar al codigo
 * @author Jesus Acosta
 * @author Rolando Rodrigo
 * @author Leonel Rojas
 */
public class Main {
    /**
     * constructor del main
     */
    public Main() {
    }

    /**Main, instancia y ejecuta el menù
     * @param args parametro obligatorio del main
     */
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.iniciar();
    }
}